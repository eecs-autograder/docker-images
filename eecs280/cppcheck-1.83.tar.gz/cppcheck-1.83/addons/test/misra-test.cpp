
// #8441
class C {
    int a;
    int b;
    C() : a(1), b(1) { c; }
};

